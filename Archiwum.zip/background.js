let color = '#3aa757';
let dupa = {
  quote: "qwer1"
};

const click = () => {
  console.log("Klik");
}