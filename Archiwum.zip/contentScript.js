//console.log(div_text);
let empty_objects = [];
const img_prefix = '/content_img/';
const imgs = ['0.png', '1.png'];

(async () => {
    div_text = [...document.getElementsByTagName('div')];
    setTimeout(function () {
        for (div of div_text) {
            if (div.classList?.contains('RichTextJSON-root')) {
                console.log(div.parentNode.parentNode);
                let text = div.innerText + "\n";
                n = div.children;
                while (n.nextElementSibling != null) {
                    text += n.nextElementSibling.innerText;
                    n.appendChild("hohohohoho");
                    n = n.nextElementSibling;
                }
                //fetch('http://127.0.0.1:5000/predict', {
                //    method: 'POST',
                //    headers: {
                //        'Content-Type': 'application/json'
                //    },
                //    body: JSON.stringify({ quote: text })
                //}).then(response => response.json()).then(response => {
                //    console.log(response);
                //    console.log(div);
                //})
            }
        }
    }, 5000);

    setInterval(function () {
        all_divs = document.getElementsByTagName('div');
        length = all_divs.length;
        for (let i = 0; i < length; i++) {
            div = all_divs[i];
            //console.log(div);
            if(div.hasAttribute('data-testid')) {
                if (div.getAttribute('data-testid') == 'post-comment-header') {
                    console.log('jest naglowek');
                    insert = document.createElement('img');
                    
                    insert.src = chrome.runtime.getURL(`${img_prefix + imgs[0]}`);
                    insert.height = 32;
                    insert.width = 32;
                    insert.style.position = 'absolute';
                    insert.style.right = '0px';
                    div.children[0].appendChild(insert);
                }
            }
        }
    }, 5000);
})();

/*
losowe_p.map((element, idx, array) => {
    if (element.innerHTML) {
        let temp = {
            quote: element.innerHTML
        }
        //element.innerText = "div_text"
        //console.log(el.innerHTML);
        empty_objects.push(temp);
    }

});
console.log(JSON.stringify(empty_objects)); //potezny obiekt
const options = {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    }
}
fetch_array = []
empty_objects.map((element, idx, array) => {
    fetch_array.push(fetch('http://127.0.0.1:5000/predict', {...options, body: JSON.stringify(element)}
    ).then(response => response.json()));
});
console.log(empty_objects)
//console.log(fetch_array);
let batch = Promise.all(fetch_array).then(response => console.log(response));
*/